package pgv.tcp.integer.binario;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Cliente {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		
		new Cliente().iniciarCliente();
	
	}
	
	public void iniciarCliente() {
		String host = "10.2.2.2";
		int puerto = 2000;
		
		try {
			Socket sCliente = new Socket(host, puerto);
			System.out.println("Cliente iniciado. Conectando con host: "+host+" al puerto: "+puerto);
			
			
			OutputStream mandarNum = sCliente.getOutputStream();
			InputStream aux = sCliente.getInputStream();

			DataOutputStream flujoSalida = new DataOutputStream(mandarNum);
			int n = (int)(Math.random()*100);
			flujoSalida.writeInt(n);
			System.out.println("Mando n�mero: "+ n );
			DataInputStream flujoEntrada = new DataInputStream(aux);
			
			System.out.println("Recibo n�mero: " + flujoEntrada.readInt());
			
			
			sCliente.close();
			System.out.println("Cliente ha terminado.");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
