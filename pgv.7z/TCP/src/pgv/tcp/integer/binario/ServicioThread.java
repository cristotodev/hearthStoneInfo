package pgv.tcp.integer.binario;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServicioThread extends Thread {

	private Socket cliente;

	public ServicioThread(Socket in) {
		cliente = in;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		try {

			
			InputStream reciboNum = cliente.getInputStream();
			OutputStream aux = cliente.getOutputStream();
			
			DataInputStream flujoEntrada = new DataInputStream(reciboNum);
			DataOutputStream flujoSalida = new DataOutputStream(aux);
			
			
			
			flujoSalida.writeInt(flujoEntrada.readInt()*2);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
				try {
					cliente.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}

	}
}
