package pgv.tcp.integer.binario;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {

	public static void main(String[] args) {
		
		new Server().iniciarServidor();
		
	}

	public void iniciarServidor() {
		int puerto = 2000;
		try {
			ServerSocket ss = new ServerSocket(puerto);
			
			System.out.println("Escuchando por el puerto: "+puerto);
			
			int i = 0;
			
			while(true) {
				
				Socket sCliente = ss.accept();
				
				new ServicioThread(sCliente).start();
				System.out.println("Cliente antendido: "+ i);
				i++;
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
}
