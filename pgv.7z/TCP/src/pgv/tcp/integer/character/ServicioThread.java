package pgv.tcp.integer.character;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServicioThread extends Thread {

	private Socket cliente;

	public ServicioThread(Socket in) {
		cliente = in;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		try {
			
			OutputStream mandarNum = cliente.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(mandarNum);
			BufferedWriter bw = new BufferedWriter(osw);
			
			InputStream recibirNum = cliente.getInputStream();
			InputStreamReader isr = new InputStreamReader(recibirNum);
			BufferedReader br = new BufferedReader(isr);
			
			String s = br.readLine();

			int num = 0;
			try {
				num = Integer.parseInt(s); 
				bw.write(String.valueOf(num*2)+"\n");
			}catch (NumberFormatException e) {
				bw.write("\n");
			}
		
			//bw.newLine();
			bw.flush();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
				try {
					cliente.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}

	}
}
