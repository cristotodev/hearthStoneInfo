package pgv.tcp.integer.character;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Cliente {

	private Socket sCliente;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Cliente().iniciarCliente();
	}
	
	public void iniciarCliente() {
		String host = "localhost";
		int puerto = 2000;
		
		try {
			sCliente = new Socket(host, puerto);
			System.out.println("Cliente iniciado. Conectando con host: "+host+" al puerto: "+puerto);
			
			OutputStream mandarNum = sCliente.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(mandarNum);
			BufferedWriter bw = new BufferedWriter(osw);
			
			InputStream recibirNum = sCliente.getInputStream();
			InputStreamReader isr = new InputStreamReader(recibirNum);
			BufferedReader br = new BufferedReader(isr);
			
			int n = (int)(Math.random()*100);
			bw.write(String.valueOf(n)+"\n");
			//bw.newLine();
			bw.flush();
			
			System.out.println("Mando n�mero: "+ n );
			
			String s = br.readLine();
			
			System.out.println("Recibo n�mero: " + s);
			
			System.out.println("Cliente ha terminado.");
			sCliente.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
