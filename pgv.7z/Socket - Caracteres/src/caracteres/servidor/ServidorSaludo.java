package caracteres.servidor;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorSaludo {
	static final int puerto = 2000;

	public ServidorSaludo() {
		try {
			ServerSocket srSocket = new ServerSocket(puerto);
			System.out.println("Servidor escuchando el puerto.... " + puerto);

			for (int i = 0; i <= 3; i++) {
				Socket stCliente = srSocket.accept();

				InputStream aux = stCliente.getInputStream();
				InputStreamReader flujo_entrada = new InputStreamReader(aux,"UTF8");
				BufferedReader br = new BufferedReader(flujo_entrada);
				String cadenaRecibida = br.readLine();
				System.out.println(cadenaRecibida);

				OutputStream salida = stCliente.getOutputStream();
				OutputStreamWriter flujoSalida = new OutputStreamWriter(salida,"UTF8");
				flujoSalida.write("Hola " + cadenaRecibida + "\n");
				flujoSalida.flush();

				stCliente.close();
			}
			System.out.println("Ya se han atendido todos los clientes");
			srSocket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public static void main(String[] args) {
		new ServidorSaludo();

	}
}
