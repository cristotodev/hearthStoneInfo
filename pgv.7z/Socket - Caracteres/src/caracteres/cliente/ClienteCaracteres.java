package caracteres.cliente;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;



public class ClienteCaracteres {
	static final String host = "localhost";
	static final int puerto = 2000;
	
	public ClienteCaracteres () {
		try {

			Socket cliente = new Socket(host, puerto);
			
			OutputStream numero = cliente.getOutputStream();
			OutputStreamWriter flujoSalida = new OutputStreamWriter(numero);
			BufferedWriter br = new BufferedWriter(flujoSalida);
			br.write(((int) (Math.random()*20+1))+"\n");
			br.flush();
			
			
			InputStream aux = cliente.getInputStream();
			
			InputStreamReader flujo_entrada = new InputStreamReader(aux);
			BufferedReader bread=new BufferedReader(flujo_entrada);  
			
			System.out.println("EL servidor me ha devuelto: "+bread.readLine());
			cliente.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new ClienteCaracteres();
	}
}
