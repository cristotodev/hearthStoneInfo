package pgv.mandarhora;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;

public class EmisorHoraUDP {

	
	static String IP = "10.2.2.255";
	static int PUERTO = 1200;
	
	public static void main(String[] args) throws IOException, InterruptedException {
	
		byte[] horaArray;
		
		DatagramSocket sSocket;
		DatagramPacket mensaje;
		
		InetAddress maquina = InetAddress.getByName(IP);
		
		ByteArrayOutputStream baos;
		ObjectOutputStream oos;
		
		while(true) {
			Date d = new Date();
			
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			
			sSocket = new DatagramSocket();
			
			oos.writeObject(d);
			
			oos.flush();
			baos.flush();
			
			horaArray = baos.toByteArray();
			
			
			mensaje = new DatagramPacket(horaArray, horaArray.length, maquina, PUERTO);
			
			sSocket.send(mensaje);
			sSocket.close();
			
			Thread.sleep(1000);
		}
		
		
		
	}
	
}
