package pgv.mandarhora;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Date;

public class ReceptorHoraUDP {

	static int PUERTO = 1200;
	
	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		byte[] horaArray;	
		DatagramSocket sSocket;
		DatagramPacket mensaje;
		
		ByteArrayInputStream bais;
		ObjectInputStream ois;
		
		
		while(true) {
			horaArray = new byte[46];
			sSocket = new DatagramSocket(PUERTO);
			mensaje = new DatagramPacket(horaArray, horaArray.length);
			
			sSocket.receive(mensaje);
			
			bais = new ByteArrayInputStream(mensaje.getData());
			ois = new ObjectInputStream(bais);
			
			Date d = (Date) ois.readObject();
			
			//System.out.println(d.getTimezoneOffset());
			//System.out.println(d.getHours());
			System.out.println(d +" -IP:"+ mensaje.getAddress());
			
			sSocket.close();
			
		}
		
		
		
		
	}
	
}
