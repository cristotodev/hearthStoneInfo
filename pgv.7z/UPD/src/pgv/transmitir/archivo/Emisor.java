package pgv.transmitir.archivo;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class Emisor {
	
	public static void main(String[] args) throws InterruptedException {
		File imagen;
		DatagramSocket socket = null;
		DatagramPacket mensaje;
		Integer puerto = 1200;
		Integer numeroDePaquetes;
		InetAddress red;
		ByteArrayOutputStream baos;
		DataOutputStream dos;
		
		byte[] buff = new byte[1000];
		int datosBuff;
		
		FileInputStream fis;
		
		try {
			imagen = new File("img.gif");
			fis = new FileInputStream(imagen);
			
			socket = new DatagramSocket();
			red = InetAddress.getByName("10.2.2.27");
			
			numeroDePaquetes = (int) Math.ceil(imagen.length() / 1000.0);
			
			
			baos = new ByteArrayOutputStream(1008);
			dos = new DataOutputStream(baos);
			for (int i = 0; i < numeroDePaquetes; i++) {
				
				//A�adir cabecera
				dos.writeInt(i);
				dos.writeInt(numeroDePaquetes);
				
				
				//alternativa for
				datosBuff = fis.read(buff);
				dos.write(buff, 0, datosBuff);
				
				/*
				for (int j = 0; j < 1000; j++) {
					dos.write(fis.read());
				}
				*/
			
				dos.flush();
				baos.flush();

				
				mensaje = new DatagramPacket(baos.toByteArray(), baos.toByteArray().length, red, puerto);
				socket.send(mensaje);
				
				//reutilizar el flujo
				baos.reset();
				
				Thread.sleep(2);
			}			
			dos.close();
			baos.close();
			
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			socket.close();
		}
	}

}
