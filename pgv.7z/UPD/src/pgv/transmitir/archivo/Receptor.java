package pgv.transmitir.archivo;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class Receptor {
	
	public static void main(String[] args) {
		Integer puerto = 1300;
		DatagramSocket socket = null;
		DatagramPacket mensaje;
		ByteArrayInputStream bais;
		DataInputStream dis;
		
		FileOutputStream fos;
		byte[] contenido;
		
		try {
			fos = new FileOutputStream(new File("prueba.gif"));
			socket = new DatagramSocket(puerto);
			contenido = new byte[1008];
			
			mensaje = new DatagramPacket(contenido, contenido.length);
			
			while(true) {
				socket.receive(mensaje);
				bais = new ByteArrayInputStream(mensaje.getData());
				dis = new DataInputStream(bais);
				
				System.out.println((dis.readInt() + 1) + "/" + dis.readInt());
				
				for (int i = 0; i < contenido.length - 8; i++) {
					fos.write(dis.read());
				}
				
				dis.close();
				bais.close();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			socket.close();
		}
	}
}
