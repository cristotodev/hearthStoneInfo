import java.net.*;
import java.util.Arrays;
import java.io.*; 

 

public class EmisorUDP { 
private static final int TAM_BLQ = 10;
  public static void main(String args [] ) { 
	  byte [] cadena, trozo;

      DatagramPacket mensaje;
    // Comprueba los argumentos

    if (args.length != 2) { 

      System.err.println("Uso: java EmisorUDP maquina mensaje"); 

    } 

    else try{ 

      // Crea el socket 

      DatagramSocket sSocket = new DatagramSocket(); 

 

      // Construye la direcci�n del socket del receptor 

      InetAddress maquina = InetAddress.getByName(args[0]); 

      int Puerto = 1500; 

 
      
      
      
      cadena = args[1].getBytes();
      // Crea el mensaje

      for (int desp = 0; desp < cadena.length; desp+=TAM_BLQ) {
    	  
    	  trozo = Arrays.copyOfRange(cadena, desp, desp+TAM_BLQ);
    	  mensaje = new DatagramPacket(trozo,trozo.length, maquina, Puerto); 
    	  sSocket.send(mensaje); 
    	  
      }
      
      

      // Env�a el mensaje 

      
      // Cierra el socket 

      sSocket.close(); 

    } catch(UnknownHostException e) { 

      System.err.println("Desconocido: " + e.getMessage()); 

    } catch(SocketException e) { 

      System.err.println("Socket: " + e.getMessage()); 

    } catch(IOException e) { 

      System.err.println("E/S: " + e.getMessage()); 

    } 

  } 

}
