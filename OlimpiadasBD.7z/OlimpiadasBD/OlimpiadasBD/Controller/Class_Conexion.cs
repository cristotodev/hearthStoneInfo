﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Carlos_OlimpiadasBD
{
    //Clase donde se guardan los datos para realizar las conexiones con la base de datos. Si se cambia de servidor, solo hay que cambiar los datos aquí.
    class Class_Conexion
    {
        //private static string strConn = "data source=10.2.2.18; initial catalog=dbOlimpiadas; integrated security=false; user=sa; password=sa";
        private static string strConn = "data source=localhost; initial catalog=dbOlimpiadas; integrated security=true;";

        //Retorna el string con la conexión para ser utilizada.
        public static string GetConexion()
        {
            return strConn;
        }
    }

}
