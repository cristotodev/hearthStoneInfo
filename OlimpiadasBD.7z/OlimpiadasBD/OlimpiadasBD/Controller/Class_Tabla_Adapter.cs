﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Carlos_OlimpiadasBD.Controller
{
    /*
     Clase para simplificar la utilización de conexiones, consulta y modificación de las tablas.
         
         */
    class Class_Tabla_Adapter
    {
        //Variables que utiliza la clase.

        //Consulta SQL que se quiere realizar.
        private String query;
        //Nombre interno en c# para las tablas de los DataSet.
        private String tabla;
        //Nombres para cada una de las columnas, de la tabla que devolverá la consulta.
        private String[] camposTabla;
        //Referencia al DataSet (conjunto de tablas) que se quieren utilizar juntas.
        private DataSet ds;
        //Referencia a la vista de la tabla para hacer las modificaciones, como ponerle nombre a las tablas.
        private DataGridView dgv;

        //DataAdapter el cual realiza la conexión y consulta SQL.
        private SqlDataAdapter da;
        //Tabla que contiene los datos.
        private DataTable dtt;
        
        //Conexión con la base de datos, con todo predefinido. (localhost, dbOlimpiadas, etc).
        private SqlConnection conn = new SqlConnection(Class_Conexion.GetConexion());

        //Constructor da la clase, que recibe tres parámetros para ser usados internamente, y dos como referencias para poder modificarlas internamente.
        public Class_Tabla_Adapter(String query, String tabla, String[] camposTabla, DataSet ds, DataGridView dgv)
        {
            this.query = query;
            this.tabla = tabla;
            this.camposTabla = camposTabla;
            this.ds = ds;
            this.dgv = dgv;
            //inicializar el DataAdapter con la consulta y la conexión.
            da = new SqlDataAdapter(query, conn);
        }

         //Para cargar la tabla de la vista con datos. Primero hay que abrir la conexión utilizando la función Open() de más abajo;
        public void CargarTabla()
        {
            //Rellena el DataSet con la tabla, y le pone nombre. 
            da.Fill(ds, tabla);
            dtt = ds.Tables[tabla];

            //Rellena el DataGridView (tabla de la vista) con  los datos.
            dgv.DataSource = dtt;

            //Y le coloca los nombres de los campos.
            for (int i = 0; i < camposTabla.Length; i++)
            {
                dgv.Columns[i].HeaderText = camposTabla[i];
            }
        }
        //Devuelve el número de filas que tiene la tabla.
        public String CantidadFilas()
        {
            return dtt.Rows.Count.ToString();
        }
    
        //Añadir a la tabla, un campo que sea un ComboBox relaciado con otra tabla del mismo DataSet.
        public void AddCombo(String propertyName, String displayName, String valueMember, DataGridView dgvnew )
        {
            DataGridViewComboBoxColumn cmb = new DataGridViewComboBoxColumn();
            cmb.DataPropertyName = propertyName;
            cmb.DisplayMember = displayName;
            cmb.ValueMember = valueMember;
            cmb.DataSource = dgvnew.DataSource;
            dgv.Columns.Add(cmb);
        }

        //Al hacer modificaciones en la tabla, que se haga lo necesario para que esos cambios se vean reflejados en la base de datos.
        public void Guardar()
        {
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(da);
            da.Update(dtt);
        }

        //Abre la conexión para poder conectar con el servidor y poder realizar la consulta y rellenar la tabla.
        public void Open()
        {
            conn.Open();
        }

        //Cierra la conexión para no gastar recursos de forma innecesaria.
        public void Close()
        {
            conn.Close();
        }
        //Getters y Setters de las variables.
        public string Query { get => query; set => query = value; }
        public string Tabla { get => tabla; set => tabla = value; }
        public string[] CamposTabla { get => camposTabla; set => camposTabla = value; }
        public DataSet Ds { get => ds; set => ds = value; }
        public DataGridView Dgv { get => dgv; set => dgv = value; }
        public SqlDataAdapter Da { get => da; set => da = value; }
        public DataTable Dtt { get => dtt; set => dtt = value; }
    }
}
