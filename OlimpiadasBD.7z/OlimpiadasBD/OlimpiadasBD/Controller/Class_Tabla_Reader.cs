﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Carlos_OlimpiadasBD.Controller
{
    //Clase para realizar consultas a la base de datos, pero sin poder modificar. Únicamente traer datos, visualizarlos y manipularlos internamente.
    class Class_Tabla_Reader
    {   //Variables que utiliza la clase.
        
        //Conexión con la base de datos con los datos predefinidos.
        SqlConnection conn = new SqlConnection(Class_Conexion.GetConexion());

        //Consulta SQL que se quiere realizar a la base de datos.
        String query;
        //Utilizado para realizar la consulta con la base de datos.
        SqlCommand command;
        //Aquí se almacena la ejecución del command.
        SqlDataReader reader;
        //Donde se guarda finalmente la tabla y los datos que se recibe de la base de datos.
        DataTable dtt = new DataTable();


        //Constructor que únicamente recibe la consulta SQL. Pero no la ejecuta, hay que utilizar Open() luego.
        public Class_Tabla_Reader(String query)
        {
            this.query = query;
            //Se realiza la conexión y se le pasa la consulta a realizar. Aún no se ha hecho la conexión.
            command = new SqlCommand(query, conn);
            
        }

        //Abre la conexión y ejecuta la consulta.
        public void Open()
        {
            conn.Open();

            reader = command.ExecuteReader();
            //Se guadan los datos de la tabla.
            dtt.Load(reader);
        }

        //Cerrar la conexión una vez realizada la consulta.
        public void Close()
        {
            conn.Close();
        }

        //Getter y Setter para poder realizar modificaciones en las variables. Sobretodo con Command al utilizar parámetros y utilizarlo para procedimientos almacenados.
        public DataTable Dtt { get => dtt; set => dtt = value; }
        public SqlCommand Command { get => command; set => command = value; }
    }
}
