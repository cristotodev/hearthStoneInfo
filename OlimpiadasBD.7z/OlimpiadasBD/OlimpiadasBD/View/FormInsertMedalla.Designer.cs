﻿namespace Carlos_OlimpiadasBD.View
{
    partial class FormInsertMedalla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.text_codigo = new System.Windows.Forms.TextBox();
            this.combo_prueba = new System.Windows.Forms.ComboBox();
            this.combo_puesto = new System.Windows.Forms.ComboBox();
            this.dtp_fecha = new System.Windows.Forms.DateTimePicker();
            this.btn_insertar = new System.Windows.Forms.Button();
            this.dgv_medallas = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_medallas)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "DNI Deportista:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prueba:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Fecha Medalla:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Puesto:";
            // 
            // text_codigo
            // 
            this.text_codigo.Location = new System.Drawing.Point(127, 28);
            this.text_codigo.Name = "text_codigo";
            this.text_codigo.Size = new System.Drawing.Size(100, 20);
            this.text_codigo.TabIndex = 4;
            // 
            // combo_prueba
            // 
            this.combo_prueba.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_prueba.FormattingEnabled = true;
            this.combo_prueba.Location = new System.Drawing.Point(127, 68);
            this.combo_prueba.Name = "combo_prueba";
            this.combo_prueba.Size = new System.Drawing.Size(213, 21);
            this.combo_prueba.TabIndex = 5;
            // 
            // combo_puesto
            // 
            this.combo_puesto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_puesto.FormattingEnabled = true;
            this.combo_puesto.Location = new System.Drawing.Point(127, 154);
            this.combo_puesto.Name = "combo_puesto";
            this.combo_puesto.Size = new System.Drawing.Size(100, 21);
            this.combo_puesto.TabIndex = 6;
            // 
            // dtp_fecha
            // 
            this.dtp_fecha.Location = new System.Drawing.Point(127, 111);
            this.dtp_fecha.MaxDate = new System.DateTime(3000, 12, 31, 0, 0, 0, 0);
            this.dtp_fecha.MinDate = new System.DateTime(1950, 1, 1, 0, 0, 0, 0);
            this.dtp_fecha.Name = "dtp_fecha";
            this.dtp_fecha.Size = new System.Drawing.Size(213, 20);
            this.dtp_fecha.TabIndex = 7;
            // 
            // btn_insertar
            // 
            this.btn_insertar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insertar.Location = new System.Drawing.Point(259, 186);
            this.btn_insertar.Name = "btn_insertar";
            this.btn_insertar.Size = new System.Drawing.Size(81, 38);
            this.btn_insertar.TabIndex = 8;
            this.btn_insertar.Text = "Insertar";
            this.btn_insertar.UseVisualStyleBackColor = true;
            this.btn_insertar.Click += new System.EventHandler(this.btn_insertar_Click);
            // 
            // dgv_medallas
            // 
            this.dgv_medallas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_medallas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_medallas.Location = new System.Drawing.Point(360, 20);
            this.dgv_medallas.Name = "dgv_medallas";
            this.dgv_medallas.Size = new System.Drawing.Size(419, 204);
            this.dgv_medallas.TabIndex = 9;
            // 
            // FormInsertMedalla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 246);
            this.Controls.Add(this.dgv_medallas);
            this.Controls.Add(this.btn_insertar);
            this.Controls.Add(this.dtp_fecha);
            this.Controls.Add(this.combo_puesto);
            this.Controls.Add(this.combo_prueba);
            this.Controls.Add(this.text_codigo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormInsertMedalla";
            this.Text = "FormInsertMedalla";
            this.Load += new System.EventHandler(this.FormInsertMedalla_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_medallas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox text_codigo;
        private System.Windows.Forms.ComboBox combo_prueba;
        private System.Windows.Forms.ComboBox combo_puesto;
        private System.Windows.Forms.DateTimePicker dtp_fecha;
        private System.Windows.Forms.Button btn_insertar;
        private System.Windows.Forms.DataGridView dgv_medallas;
    }
}