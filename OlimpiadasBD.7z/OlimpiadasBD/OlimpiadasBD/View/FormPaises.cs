﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD
{
    public partial class FormPaises : Form
    {
        //Ventana para ver los paises.

        
        private DataSet ds;
        private Class_Tabla_Adapter t_paises;
        public FormPaises()
        {
            InitializeComponent();
        }

        private void formPAises_Load(object sender, EventArgs e)
        {
            RellenarTabla();
            
        }
        //Rellenar la tabla con los elementos de la base de datos.
        private void RellenarTabla()
        {
            try
            {
                ds = new DataSet();
                String consulta = "select * from paises;";
                String tabla = "t_paises";
                String[] camposTabla = new String[] { "Código", "Nombre" };

                t_paises = new Class_Tabla_Adapter(consulta, tabla, camposTabla, ds, dgv_paises);
                t_paises.CargarTabla();
            }
            catch
            {
                MessageBox.Show("Error al cargar la tabla.");
            }
        }
        //Botón para guardar las modificaciones que se realizan en la tabla.
        private void btn_guardar_paises_Click(object sender, EventArgs e)
        {

            try
            {
                t_paises.Guardar();
                MessageBox.Show("Modificación realizada");
            }
            catch
            {
                MessageBox.Show("No se ha podido realizar la modificación.");
            }
            
        }

    }
}
