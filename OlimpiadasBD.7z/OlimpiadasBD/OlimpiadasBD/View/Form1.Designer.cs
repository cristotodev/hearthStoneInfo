﻿namespace OlimpiadasBD
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_paises = new System.Windows.Forms.Button();
            this.btn_pai_dep = new System.Windows.Forms.Button();
            this.btn_combo = new System.Windows.Forms.Button();
            this.btn_insert_medalla = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorServidor = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_pruebas_medallas = new System.Windows.Forms.Button();
            this.btn_listar_deportistas = new System.Windows.Forms.Button();
            this.btn_cantidad_medallas = new System.Windows.Forms.Button();
            this.btn_deportista_pais = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.colorServidor)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_paises
            // 
            this.btn_paises.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_paises.Location = new System.Drawing.Point(12, 61);
            this.btn_paises.Name = "btn_paises";
            this.btn_paises.Size = new System.Drawing.Size(120, 100);
            this.btn_paises.TabIndex = 0;
            this.btn_paises.Text = "Ver Paises";
            this.btn_paises.UseVisualStyleBackColor = true;
            this.btn_paises.Click += new System.EventHandler(this.btn_paises_Click);
            // 
            // btn_pai_dep
            // 
            this.btn_pai_dep.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pai_dep.Location = new System.Drawing.Point(138, 61);
            this.btn_pai_dep.Name = "btn_pai_dep";
            this.btn_pai_dep.Size = new System.Drawing.Size(120, 100);
            this.btn_pai_dep.TabIndex = 1;
            this.btn_pai_dep.Text = "Insertar Paises Deportistas";
            this.btn_pai_dep.UseVisualStyleBackColor = true;
            this.btn_pai_dep.Click += new System.EventHandler(this.btn_pai_dep_Click);
            // 
            // btn_combo
            // 
            this.btn_combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_combo.Location = new System.Drawing.Point(264, 61);
            this.btn_combo.Name = "btn_combo";
            this.btn_combo.Size = new System.Drawing.Size(120, 100);
            this.btn_combo.TabIndex = 2;
            this.btn_combo.Text = "Combo Deportistas Medallas";
            this.btn_combo.UseVisualStyleBackColor = true;
            this.btn_combo.Click += new System.EventHandler(this.btn_combo_Click);
            // 
            // btn_insert_medalla
            // 
            this.btn_insert_medalla.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insert_medalla.Location = new System.Drawing.Point(390, 61);
            this.btn_insert_medalla.Name = "btn_insert_medalla";
            this.btn_insert_medalla.Size = new System.Drawing.Size(120, 100);
            this.btn_insert_medalla.TabIndex = 3;
            this.btn_insert_medalla.Text = "Insertar Medallas";
            this.btn_insert_medalla.UseVisualStyleBackColor = true;
            this.btn_insert_medalla.Click += new System.EventHandler(this.btn_insert_medalla_Click);
            // 
            // colorServidor
            // 
            this.colorServidor.Location = new System.Drawing.Point(22, 12);
            this.colorServidor.Name = "colorServidor";
            this.colorServidor.Size = new System.Drawing.Size(34, 31);
            this.colorServidor.TabIndex = 4;
            this.colorServidor.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Conexión con el servidor.";
            // 
            // btn_pruebas_medallas
            // 
            this.btn_pruebas_medallas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pruebas_medallas.Location = new System.Drawing.Point(516, 61);
            this.btn_pruebas_medallas.Name = "btn_pruebas_medallas";
            this.btn_pruebas_medallas.Size = new System.Drawing.Size(120, 100);
            this.btn_pruebas_medallas.TabIndex = 6;
            this.btn_pruebas_medallas.Text = "Visualizar Pruebas Medallas";
            this.btn_pruebas_medallas.UseVisualStyleBackColor = true;
            this.btn_pruebas_medallas.Click += new System.EventHandler(this.btn_pruebas_medallas_Click);
            // 
            // btn_listar_deportistas
            // 
            this.btn_listar_deportistas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_listar_deportistas.Location = new System.Drawing.Point(12, 167);
            this.btn_listar_deportistas.Name = "btn_listar_deportistas";
            this.btn_listar_deportistas.Size = new System.Drawing.Size(120, 100);
            this.btn_listar_deportistas.TabIndex = 7;
            this.btn_listar_deportistas.Text = "Listar Deportistas";
            this.btn_listar_deportistas.UseVisualStyleBackColor = true;
            this.btn_listar_deportistas.Click += new System.EventHandler(this.btn_listar_deportistas_Click);
            // 
            // btn_cantidad_medallas
            // 
            this.btn_cantidad_medallas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cantidad_medallas.Location = new System.Drawing.Point(264, 167);
            this.btn_cantidad_medallas.Name = "btn_cantidad_medallas";
            this.btn_cantidad_medallas.Size = new System.Drawing.Size(120, 100);
            this.btn_cantidad_medallas.TabIndex = 8;
            this.btn_cantidad_medallas.Text = "Cantidad Medallas";
            this.btn_cantidad_medallas.UseVisualStyleBackColor = true;
            this.btn_cantidad_medallas.Click += new System.EventHandler(this.btn_cantidad_medallas_Click);
            // 
            // btn_deportista_pais
            // 
            this.btn_deportista_pais.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deportista_pais.Location = new System.Drawing.Point(516, 167);
            this.btn_deportista_pais.Name = "btn_deportista_pais";
            this.btn_deportista_pais.Size = new System.Drawing.Size(120, 100);
            this.btn_deportista_pais.TabIndex = 9;
            this.btn_deportista_pais.Text = "Deportista Pais";
            this.btn_deportista_pais.UseVisualStyleBackColor = true;
            this.btn_deportista_pais.Click += new System.EventHandler(this.btn_deportista_pais_Click);
            // 
            // timer1
            // 
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 282);
            this.Controls.Add(this.btn_deportista_pais);
            this.Controls.Add(this.btn_cantidad_medallas);
            this.Controls.Add(this.btn_listar_deportistas);
            this.Controls.Add(this.btn_pruebas_medallas);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.colorServidor);
            this.Controls.Add(this.btn_insert_medalla);
            this.Controls.Add(this.btn_combo);
            this.Controls.Add(this.btn_pai_dep);
            this.Controls.Add(this.btn_paises);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.colorServidor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_paises;
        private System.Windows.Forms.Button btn_pai_dep;
        private System.Windows.Forms.Button btn_combo;
        private System.Windows.Forms.Button btn_insert_medalla;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.PictureBox colorServidor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_pruebas_medallas;
        private System.Windows.Forms.Button btn_listar_deportistas;
        private System.Windows.Forms.Button btn_cantidad_medallas;
        private System.Windows.Forms.Button btn_deportista_pais;
        private System.Windows.Forms.Timer timer1;
    }
}

