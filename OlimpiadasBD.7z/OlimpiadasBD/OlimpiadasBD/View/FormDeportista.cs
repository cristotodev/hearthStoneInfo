﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD
{
    public partial class FormDeportista : Form
    {
        //Tablas necesarias.
        DataSet ds = new DataSet();
        Class_Tabla_Adapter t_paises;
        Class_Tabla_Adapter t_deportistas;

        //Datos de la tabla paises.
        String queryPaises = "SELECT * FROM paises";
        String tablaPaises = "t_paises";
        String[] columnaPaises = new String[] { "Código", "Nombre" };

        //Datos de la tabla deportistas.
        String queryDeportistas = "SELECT * FROM deportistas";
        String tablaDeportistas = "t_deportistas";
        String[] columnaDeportistas = new String[] { "Código", "Nombre", "DNI", "CódigoPais" };


        public FormDeportista()
        {
            InitializeComponent();
        }
        private void formDeportisa_Load(object sender, EventArgs e)
        {
            RellenarTablas();
        }

        //Con los datos aportados anteriormente, se rellenan las tablas.
        private void RellenarTablas()
        {
            try
            {
                t_paises = new Class_Tabla_Adapter(queryPaises, tablaPaises, columnaPaises, ds, dgv_paises);
                t_paises.CargarTabla();

                t_deportistas = new Class_Tabla_Adapter(queryDeportistas, tablaDeportistas, columnaDeportistas, ds, dgv_dep);
                t_deportistas.CargarTabla();

                cargarComboDeportistas();
                contarFilas();
            }
            catch
            {
                MessageBox.Show("Error al cargar la tabla.");
            }
        }

        //Guardar los cambios hechos en las tablas.
        private void btn_guardar_Click(object sender, EventArgs e)
        {
            String log = "";
          
            try
            {
                t_paises.Guardar();
                log += "Se pudo modificar la tabla paises.\n";
            }
            catch
            {
                log += "ERROR al modificar la tabla paises.\n";
            }

            try
            {
                t_deportistas.Guardar();
                log += "Se pudo modificar la tabla deportistas.\n";
            }
            catch
            {
                log += "ERROR al modificar la tabla deportistas.\n";
            }
            MessageBox.Show(log);
            RecargarTabla();
        }
        
        //Contar el número de filas o registros que hay en las tablas para mostrar.
        private void contarFilas()
        {
            count_paises.Text = t_paises.CantidadFilas();
            count_dep.Text = t_deportistas.CantidadFilas();
        }
        
        //Ejecutar la función que rellena el DataSet y mete los datos en la vista.
        private void cargarTablas()
        {
            t_paises.CargarTabla();
            t_deportistas.CargarTabla();
        }
        
        //Añadir en la tabla deportistas, un campo que sea ComboBox relacionada con la otra tabla del DataSet paises.
        private void cargarComboDeportistas()
        {

            String propertyName = "paisDeportista";
            String displayName = "nombrePais";
            String valueMember = "codPais";
            
            t_deportistas.AddCombo(propertyName,displayName, valueMember, dgv_paises);
            
            dgv_dep.Columns[4].HeaderText = "Pais";
        }

        //Recargar los datos cuando se ha hecho un guardado.
        private void RecargarTabla()
        {
            ds.Clear();
            cargarTablas();
            contarFilas();
        }
    }
}
