﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD.View
{
    public partial class FormCombo : Form
    {
        //Tablas necesarias.
        private Class_Tabla_Adapter t_tabla;
        private DataSet ds;

        public FormCombo()
        {
            InitializeComponent();
        }

        private void FormCombo_Load(object sender, EventArgs e)
        {
            ds = new DataSet();
            CargarComboPaises();
        }
        
        //Rellenar el combo con los datos de la base de datos, en modo lectura únicamente.
        private void CargarComboPaises()
        {
            String lista = "select * from paises";
            Class_Tabla_Reader ctr = new Class_Tabla_Reader(lista);

            try
            {
                ctr.Open();

                combo_paises.DataSource = ctr.Dtt;
                combo_paises.DisplayMember = "nombrePais";
                combo_paises.ValueMember = "codPais";
                combo_paises.SelectedIndex = -1;
                combo_paises.SelectedIndex = 0;

                ctr.Close();
            }
            catch
            {
                MessageBox.Show("No se ha podido cargar la tabla.");
            }
        }

        //Cada vez que se hace un cambio en la selección del ComboBox, se ejecuta la función interior.
        private void combo_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
            RellenarTabla();
        }

        //Se hace una búsqueda a través del texto del ComboBox en la base de datos, para saber los deportistas pertenecientes a ese pais.
        private void RellenarTabla()
        {
            String query = "select * from deportistas where paisDeportista = @campo";
            String tabla = "t_deportistas";
            String[] camposTabla = new String[] { "Código", "Nombre", "DNI", "CódigoPais" };
            ds.Clear();
            
            t_tabla = new Class_Tabla_Adapter(query, tabla, camposTabla, ds, dgv_deportistas);

            t_tabla.Da.SelectCommand.Parameters.AddWithValue("@campo", combo_paises.SelectionLength).Value = combo_paises.SelectedValue;
            try
            {
                t_tabla.CargarTabla();
            }
            catch
            {

            }
        }

        //Listener de la vista de la tabla, cada vez que se seleccione un elemento, se crea una nueva ventana, en el cual sale información relacionada de las medallas.
        private void dgv_deportistas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FormComboMedallas fcm = new FormComboMedallas();
            fcm.CodMedalla = dgv_deportistas.Rows[e.RowIndex].Cells[0].Value.ToString();
            String nombre = dgv_deportistas.Rows[e.RowIndex].Cells[1].Value.ToString();
            String codigo = dgv_deportistas.Rows[e.RowIndex].Cells[0].Value.ToString();
            String dni = dgv_deportistas.Rows[e.RowIndex].Cells[2].Value.ToString();
            String pais = combo_paises.Text;

            fcm.rellenarDeportista(nombre, dni, codigo, pais);
            fcm.Show();
            
        }
    }
}
