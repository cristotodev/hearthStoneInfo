﻿using Carlos_OlimpiadasBD.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Carlos_OlimpiadasBD.View
{
    public partial class FormInsertMedalla : Form
    {
        public FormInsertMedalla()
        {
            InitializeComponent();
        }

        private void FormInsertMedalla_Load(object sender, EventArgs e)
        {

            try
            {
                //Rellenar la tabla de medallas.
                RellenarTabla();
                //Rellennar el ComboBox de pruebas con valores de la base de datos.
                RellenarComboPrueba();
            }
            catch
            {
                MessageBox.Show("No se ha podido conectar con el servidor.");
            }

            //Rellenar el ComboBox de puestos con valores fijos.
            RellenarComboPuesto();
        }

        //Rellenar el ComboBox de pruebas con datos de la tabla.
        private void RellenarComboPrueba()
        {
            String lista = "select * from pruebas";
            Class_Tabla_Reader ctr = new Class_Tabla_Reader(lista);

            ctr.Open();

            combo_prueba.DataSource = ctr.Dtt;
            combo_prueba.DisplayMember = "nombrePrueba";
            combo_prueba.ValueMember = "codPrueba";

            ctr.Close();

        }

        //Rellenar la tabla de medallas.
        private void RellenarTabla()
        {
            String lista = "select * from medallas";
            Class_Tabla_Reader ctr = new Class_Tabla_Reader(lista);

            ctr.Open();

            dgv_medallas.DataSource = ctr.Dtt;

            ctr.Close();

        }

        //Comprobación de todos los datos introducidos, y si son correctos, se realiza la inserción de los datos.
        private void btn_insertar_Click(object sender, EventArgs e)
        {   bool error = false;
            string errores = "";

            String dniDep = "";
            String codPrueba = "";
            DateTime fechaMed = DateTime.Now;
            String puesto = "";

            
            try
            {
                dniDep = text_codigo.Text;
                codPrueba = combo_prueba.SelectedValue.ToString();
                fechaMed = dtp_fecha.Value;
                puesto = combo_puesto.SelectedItem.ToString();
            }
            catch
            {
                error = true;
                errores = "Asignación de campos incompleta.";
            }

            

            String pattern = "^[0-9]{2}[.][0-9]{3}[.][0-9]{3}[-][A-Z]{1}";
            Regex regex = new Regex(pattern);

            //Comprobar el patrón del dni.
            if (!regex.IsMatch(dniDep))
            {
                error = true;
                errores += "El DNI es incorrecto. Debe tener el formato 00.000.000-X.\n";
            }

            //Comprobar que la fecha no sea superior al dia de hoy.
            if (fechaMed.CompareTo(DateTime.Now) > 0)
            {
                error = true;
                errores += "La fecha es incorrecta, no puede superar al dia de hoy.\n";
            }

            //Comprobar que el deportista con ese dni existe.
            if (!ComprobarDniDB(dniDep))
            {
                error = true;
                errores += "El deportista introducido no existe.\n";
            }
            else
            {
                //Comprobar que esa combinación de datos (la medalla en si) ya existe.
                if (!ComprobarExisteMedalla(RecogerCodigo(dniDep), codPrueba, fechaMed, puesto))
                {
                    error = true;
                    errores += "Ya existe esa medalla.\n";
                }
            }

            if (!error)
            {
                //Hacer la inserción a través del procedimiennto.
                SqlConnection conn = new SqlConnection(Class_Conexion.GetConexion());
                conn.Open();
                SqlCommand command = new SqlCommand("pInserteMedalla", conn);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@Pdni", dniDep);
                command.Parameters.AddWithValue("@PcodPrueba", codPrueba);
                command.Parameters.AddWithValue("@PfechaMedalla", fechaMed);
                command.Parameters.AddWithValue("@PpuestoDeportista", puesto);

                command.ExecuteNonQuery();
                conn.Close();


            }
            else
            {
                MessageBox.Show(errores);
            }

            RellenarTabla();
        }
        //Comprobar un dni que se le pasa por parámetro, a ver si está en la base de datos. Si el número es mayor a 0, TRUE, es que sí hay deportista.
        private bool ComprobarDniDB(String dni)
        {

            SqlConnection conn = new SqlConnection(Class_Conexion.GetConexion());
            conn.Open();
            SqlCommand command = new SqlCommand("select count(*) from deportistas where dniDeportista = @dni", conn);
            command.Parameters.AddWithValue("@dni", dni);
            int a = (Int32)command.ExecuteScalar();

            return a != 0;
        }

        //Comprobar si existe una medalla. Si el número es mayor a 0, TRUE, es que sí hay medallas con esos datos.
        private bool ComprobarExisteMedalla(int codDep, String codPrueba, DateTime fechaMedalla, String puesto)
        {
            SqlConnection conn = new SqlConnection(Class_Conexion.GetConexion());
            conn.Open();
            SqlCommand command = new SqlCommand("select count(*) from medallas where codDeportista = @codDep and codPrueba = @codPru and fechaMedalla = @fechaMed and puestoDeportista = @puestoDep", conn);
            command.Parameters.AddWithValue("@codDep", codDep);
            command.Parameters.AddWithValue("@codPru", codPrueba);
            command.Parameters.AddWithValue("@fechaMed", fechaMedalla);
            command.Parameters.AddWithValue("@puestoDep", puesto);

            int a = (Int32)command.ExecuteScalar();

            return a != 0;
        }

        //Recoger el Código de deportista a través de un DNI.
        private int RecogerCodigo(String dni)
        {
            SqlConnection conn = new SqlConnection(Class_Conexion.GetConexion());
            conn.Open();
            SqlCommand command = new SqlCommand("select codDeportista from deportistas where dniDeportista = @dni", conn);
            command.Parameters.AddWithValue("@dni", dni);
            int a = (Int32)command.ExecuteScalar();

            return a;
        }

        //Rellenar el combo del puesto con valores fijos.
        private void RellenarComboPuesto()
        {
            combo_puesto.Items.Add(1);
            combo_puesto.Items.Add(2);
            combo_puesto.Items.Add(3);
            combo_puesto.SelectedIndex = 0;
        }

        //Función no utilizada, es un listener para que en un TextField o como se llamen aquí, solo se puedan escribir números.
        /*
        private void text_codigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)) && (e.KeyChar != (char)Keys.Back))
            {
                e.Handled = true;
                return;
            }
        }
        */

    }
}
