﻿using Carlos_OlimpiadasBD.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Carlos_OlimpiadasBD.View
{
    public partial class FormPruebaMedalla : Form
    {
        Class_Tabla_Adapter cta_Pruebas;
        Class_Tabla_Adapter cta_Medallas;
        DataSet ds;

        DataColumn columnaPadre;
        DataColumn columnaHijo;

        DataRelation dr;

        public FormPruebaMedalla()
        {
            InitializeComponent();
        }

        private void FormPruebaMedalla_Load(object sender, EventArgs e)
        {

            ds = new DataSet();

            try
            {
                RellenarPrueba();
                RellenarMedalla();

                columnaPadre = ds.Tables["t_pruebas"].Columns["codPrueba"];
                columnaHijo = ds.Tables["t_medallas"].Columns["codPrueba"];

                dr = new DataRelation("t_MedallasPruebas", columnaPadre, columnaHijo);
                ds.Relations.Add(dr);
            }
            catch
            {
                MessageBox.Show("No se ha podido rellenar las tablas.");
            }
            
        }

        //Rellenar la tabla de pruebas.
        private void RellenarPrueba()
        {
            String pru_query = "select * from pruebas";
            String pru_tabla = "t_pruebas";
            String[] pru_columnas = new string[] { "Código", "Nombre", "Deporte" };
            cta_Pruebas = new Class_Tabla_Adapter(pru_query, pru_tabla, pru_columnas, ds, dgv_pruebas);
            cta_Pruebas.CargarTabla();
        }

        //Rellenar la tabla de medallas con los valores iniciales.
        private void RellenarMedalla()
        {
            String med_query = "select * from medallas";
            String med_tabla = "t_medallas";
            String[] med_columnas = new string[] { "Código", "Prueba", "Fecha" , "Puesto"};
            cta_Medallas = new Class_Tabla_Adapter(med_query, med_tabla, med_columnas, ds, dgv_medallas);
            cta_Medallas.CargarTabla();
        }

        //Listener de la tabla pruebas, para que cuando se pise en una determinada prueba, en la tabla de medallas se cambien los datos por los relacionados.
        private void dgv_pruebas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataRowView currentRowView;
            DataView tableView = new DataView(ds.Tables["t_pruebas"]);

            currentRowView = tableView[dgv_pruebas.CurrentRow.Index];

            dgv_medallas.DataSource = currentRowView.CreateChildView("t_MedallasPruebas");
            
        }
    }
}
