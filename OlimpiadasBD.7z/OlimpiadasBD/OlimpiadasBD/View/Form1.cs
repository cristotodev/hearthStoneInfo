﻿using Carlos_OlimpiadasBD;
using System;
using System.Drawing;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.View;
using System.Data.SqlClient;
using System.Threading;
using Carlos_OlimpiadasBD.View_Procedimientos;

namespace OlimpiadasBD
{

    //Vista con el menú general de la aplicación.
    //El programa tiene las siguientes funciones en cada uno de sus botones.

    //Ver Paises - Se obtienen los paises de la base de datos y se muestran en una vista de tabla. No se pueden modificar los datos.
    //Insertar Paises Deportistas - Se obtienen las vistas de los paises, y los deportistas. Sí se puede modificar los datos al presionar el botón guardar.
    //Combo Deportistas Medallas - Se obtienen las medallas a través de un ComboBox de paises. No se puede modificar los datos.
    //Insertar Medallas - Formulario con los datos necesarios para realizar la insersión de los datos. También se visualizan las medallas. (Utiliza procedimiento)
    //Visualizar Pruebas Medallas - Visualiza las pruebas que hay, y cuando se presione en una de las pruebas, la visualización de medallas va cambiando con las medallas correspondientes de esa prueba.
    //Listar Deportistas - Muestra los deportistas de un país en concreto. (Utiliza procedimiento)
    //Cantidad Medallas - Muestra la cantidad de las distintas medallas de un país en concreto.(Utiliza procedimiento)
    //Deportista País - Muestra la cantidad de deportistas de un país en concreto.
    
    public partial class Form1 : Form
    {
        
        SqlConnection c;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //Dar forma redonda al componente visual de comprobación de conexión
            System.Drawing.Drawing2D.GraphicsPath objDraw = new System.Drawing.Drawing2D.GraphicsPath();
            objDraw.AddEllipse(0, 0, colorServidor.Width-5, colorServidor.Height-5);

            //Dar color (en principio rojo) al componente visual de comprobación de conexión
            colorServidor.Region  = new Region(objDraw);
            c = new SqlConnection(Class_Conexion.GetConexion());
            colorServidor.BackColor = Color.Red;
            colorServidor.BorderStyle = BorderStyle.Fixed3D;
            
            //Lanzar el hilo en segundo plano para comprobar periódicamente la conexión con el servidor y cambiar de color el componente según corresponda.
            Thread th = new Thread(ComprobarConexion);
            th.IsBackground = true;
            th.Start();
        }
        
        private void btn_paises_Click(object sender, EventArgs e)
        {
            if(CanConect())
                new FormPaises().Show();
        }

        private void btn_pai_dep_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormDeportista().Show();
        }
        private void btn_combo_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormCombo().Show();
        }

        private void btn_insert_medalla_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormInsertMedalla().Show();
        }

        private void btn_pruebas_medallas_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormPruebaMedalla().Show();
        }

        private void btn_listar_deportistas_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormListarDeportistas().Show();
        }

        private void btn_cantidad_medallas_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormCantidadMedallas().Show();
        }

        private void btn_deportista_pais_Click(object sender, EventArgs e)
        {
            if (CanConect())
                new FormDepPais().Show();
        }

        //Si el componente de conexión está en rojo, no se permite lanzar la nueva ventana
        private bool CanConect()
        {
            if (colorServidor.BackColor == Color.Red)
                MessageBox.Show("No se puede conectar con el servidor.");
            return colorServidor.BackColor == Color.Green;
        }

        //Función que comprueba la conexión con el servidor, y cambia de color el componente cuando es necesario
        private void ComprobarConexion()
        {

            while (true)
            {
                try
                {
                    c.Open();
                    colorServidor.BackColor = Color.Green;

                }
                catch
                {
                    colorServidor.BackColor = Color.Red;
                }
                c.Close();
                Thread.Sleep(1000);
                
            }
            
        }


    }
}
