﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD.View
{
    //Clase utilizada por FormCombo para mostrar las medallas.
    public partial class FormComboMedallas : Form
    {
        //Variables necesarias.
        private String codMedalla;

        private String nombre;
        private String codigo;
        private String dni;
        private String pais;

        public FormComboMedallas()
        {
            InitializeComponent();
        }
        
        //Cuando ya se tienen todos los datos, se ejecuta la función SHOW desde donde se esté utilizando esta clase.
        private void FormComboMedallas_Load(object sender, EventArgs e)
        {
            
            nombreLabel.Text = nombre;
            codLabel.Text = codigo;
            dniLabel.Text = dni;
            paisLabel.Text = pais;
            
            Class_Tabla_Reader ctr = new Class_Tabla_Reader("select * from medallas where codDeportista = @campo");
            ctr.Command.Parameters.Add("@campo", SqlDbType.Int).Value = Int32.Parse(codMedalla);
            ctr.Open();

            dgv_medallas.DataSource = ctr.Dtt;

            ctr.Close();
            
        }

        //Antes de ejecutar la función SHOW, hay que utilizar esta función para pasar los parámetros necesarios para mostrar en los LABEL.
        public void rellenarDeportista(String nombre, String dni, String codigo, String pais)
        {
            this.nombre = nombre;
            this.codigo = codigo;
            this.dni = dni;
            this.pais = pais;
            
        }

        public string CodMedalla { get => codMedalla; set => codMedalla = value; }
    }
}
