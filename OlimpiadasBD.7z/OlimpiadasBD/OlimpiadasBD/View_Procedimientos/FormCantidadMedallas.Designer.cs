﻿namespace Carlos_OlimpiadasBD.View_Procedimientos
{
    partial class FormCantidadMedallas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.combo_paises = new System.Windows.Forms.ComboBox();
            this.textOro = new System.Windows.Forms.Label();
            this.textPlata = new System.Windows.Forms.Label();
            this.textBronce = new System.Windows.Forms.Label();
            this.oroLabel = new System.Windows.Forms.Label();
            this.plataLabel = new System.Windows.Forms.Label();
            this.bronceLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // combo_paises
            // 
            this.combo_paises.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_paises.FormattingEnabled = true;
            this.combo_paises.Location = new System.Drawing.Point(22, 12);
            this.combo_paises.Name = "combo_paises";
            this.combo_paises.Size = new System.Drawing.Size(174, 21);
            this.combo_paises.TabIndex = 0;
            this.combo_paises.SelectedIndexChanged += new System.EventHandler(this.combo_paises_SelectedIndexChanged);
            // 
            // textOro
            // 
            this.textOro.AutoSize = true;
            this.textOro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textOro.Location = new System.Drawing.Point(19, 64);
            this.textOro.Name = "textOro";
            this.textOro.Size = new System.Drawing.Size(113, 17);
            this.textOro.TabIndex = 1;
            this.textOro.Text = "Medallas de oro:";
            // 
            // textPlata
            // 
            this.textPlata.AutoSize = true;
            this.textPlata.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPlata.Location = new System.Drawing.Point(19, 104);
            this.textPlata.Name = "textPlata";
            this.textPlata.Size = new System.Drawing.Size(123, 17);
            this.textPlata.TabIndex = 2;
            this.textPlata.Text = "Medallas de plata:";
            // 
            // textBronce
            // 
            this.textBronce.AutoSize = true;
            this.textBronce.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBronce.Location = new System.Drawing.Point(19, 146);
            this.textBronce.Name = "textBronce";
            this.textBronce.Size = new System.Drawing.Size(136, 17);
            this.textBronce.TabIndex = 3;
            this.textBronce.Text = "Medallas de bronce:";
            // 
            // oroLabel
            // 
            this.oroLabel.AutoSize = true;
            this.oroLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oroLabel.Location = new System.Drawing.Point(171, 64);
            this.oroLabel.Name = "oroLabel";
            this.oroLabel.Size = new System.Drawing.Size(23, 17);
            this.oroLabel.TabIndex = 4;
            this.oroLabel.Text = "---";
            // 
            // plataLabel
            // 
            this.plataLabel.AutoSize = true;
            this.plataLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.plataLabel.Location = new System.Drawing.Point(171, 104);
            this.plataLabel.Name = "plataLabel";
            this.plataLabel.Size = new System.Drawing.Size(23, 17);
            this.plataLabel.TabIndex = 5;
            this.plataLabel.Text = "---";
            // 
            // bronceLabel
            // 
            this.bronceLabel.AutoSize = true;
            this.bronceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bronceLabel.Location = new System.Drawing.Point(171, 146);
            this.bronceLabel.Name = "bronceLabel";
            this.bronceLabel.Size = new System.Drawing.Size(23, 17);
            this.bronceLabel.TabIndex = 6;
            this.bronceLabel.Text = "---";
            // 
            // FormCantidadMedallas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(240, 204);
            this.Controls.Add(this.bronceLabel);
            this.Controls.Add(this.plataLabel);
            this.Controls.Add(this.oroLabel);
            this.Controls.Add(this.textBronce);
            this.Controls.Add(this.textPlata);
            this.Controls.Add(this.textOro);
            this.Controls.Add(this.combo_paises);
            this.Name = "FormCantidadMedallas";
            this.Text = "FormCantidadMedallas";
            this.Load += new System.EventHandler(this.FormCantidadMedallas_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_paises;
        private System.Windows.Forms.Label textOro;
        private System.Windows.Forms.Label textPlata;
        private System.Windows.Forms.Label textBronce;
        private System.Windows.Forms.Label oroLabel;
        private System.Windows.Forms.Label plataLabel;
        private System.Windows.Forms.Label bronceLabel;
    }
}