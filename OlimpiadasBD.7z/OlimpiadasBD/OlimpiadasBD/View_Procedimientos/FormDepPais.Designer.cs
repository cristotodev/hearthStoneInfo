﻿namespace Carlos_OlimpiadasBD.View_Procedimientos
{
    partial class FormDepPais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.combo_paises = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label_cantidad = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // combo_paises
            // 
            this.combo_paises.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_paises.FormattingEnabled = true;
            this.combo_paises.Location = new System.Drawing.Point(57, 12);
            this.combo_paises.Name = "combo_paises";
            this.combo_paises.Size = new System.Drawing.Size(162, 21);
            this.combo_paises.TabIndex = 0;
            this.combo_paises.SelectedIndexChanged += new System.EventHandler(this.combo_paises_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cantidad:";
            // 
            // label_cantidad
            // 
            this.label_cantidad.AutoSize = true;
            this.label_cantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cantidad.Location = new System.Drawing.Point(115, 61);
            this.label_cantidad.Name = "label_cantidad";
            this.label_cantidad.Size = new System.Drawing.Size(19, 25);
            this.label_cantidad.TabIndex = 2;
            this.label_cantidad.Text = "-";
            // 
            // FormDepPais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 113);
            this.Controls.Add(this.label_cantidad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combo_paises);
            this.Name = "FormDepPais";
            this.Text = "FormDeportistas";
            this.Load += new System.EventHandler(this.FormDepPais_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_paises;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_cantidad;
    }
}