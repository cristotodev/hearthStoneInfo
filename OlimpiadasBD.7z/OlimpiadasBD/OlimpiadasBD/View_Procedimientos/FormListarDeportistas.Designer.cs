﻿namespace Carlos_OlimpiadasBD.View_Procedimientos
{
    partial class FormListarDeportistas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.combo_paises = new System.Windows.Forms.ComboBox();
            this.dgv_deportistas = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_deportistas)).BeginInit();
            this.SuspendLayout();
            // 
            // combo_paises
            // 
            this.combo_paises.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_paises.FormattingEnabled = true;
            this.combo_paises.Location = new System.Drawing.Point(12, 12);
            this.combo_paises.Name = "combo_paises";
            this.combo_paises.Size = new System.Drawing.Size(175, 21);
            this.combo_paises.TabIndex = 0;
            this.combo_paises.SelectedIndexChanged += new System.EventHandler(this.combo_paises_SelectedIndexChanged);
            // 
            // dgv_deportistas
            // 
            this.dgv_deportistas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_deportistas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_deportistas.Location = new System.Drawing.Point(13, 40);
            this.dgv_deportistas.Name = "dgv_deportistas";
            this.dgv_deportistas.Size = new System.Drawing.Size(174, 204);
            this.dgv_deportistas.TabIndex = 1;
            // 
            // FormListarDeportistas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(200, 256);
            this.Controls.Add(this.dgv_deportistas);
            this.Controls.Add(this.combo_paises);
            this.Name = "FormListarDeportistas";
            this.Text = "FormListarDeportistas";
            this.Load += new System.EventHandler(this.FormListarDeportistas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_deportistas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_paises;
        private System.Windows.Forms.DataGridView dgv_deportistas;
    }
}