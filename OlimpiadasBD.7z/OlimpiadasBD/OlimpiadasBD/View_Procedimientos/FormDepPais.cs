﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD.View_Procedimientos
{
    public partial class FormDepPais : Form
    {

        Class_Tabla_Reader t_tabla;

        public FormDepPais()
        {
            InitializeComponent();
        }

        private void FormDepPais_Load(object sender, EventArgs e)
        {
            RellenarComboPaises();
        }

        //Rellenar el ComboBox con todos los paises de la base de datos.
        private void RellenarComboPaises()
        {
            String lista = "select * from paises";
            Class_Tabla_Reader ctr = new Class_Tabla_Reader(lista);

            try
            {
                ctr.Open();

                combo_paises.DataSource = ctr.Dtt;
                combo_paises.DisplayMember = "nombrePais";
                combo_paises.ValueMember = "codPais";
                combo_paises.SelectedIndex = -1;
                combo_paises.SelectedIndex = 0;

                ctr.Close();
            }
            catch
            {
                MessageBox.Show("No se ha podido cargar la tabla.");
            }

        }

        //Listener del ComboBox, en el que se realiza la función de la base de datos, que recoge un país y devuelve la cantidad de deportistas.
        private void combo_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            t_tabla = new Class_Tabla_Reader("select dbo.fDeportistaPais(@pais)");
            t_tabla.Command.Parameters.AddWithValue("@pais",combo_paises.Text);

            t_tabla.Open();

            String cant = t_tabla.Dtt.Rows[0][0].ToString();

            t_tabla.Close();
            label_cantidad.Text = cant;
            
        }
    }
}
