﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD.View_Procedimientos
{
    public partial class FormCantidadMedallas : Form
    {
        Class_Tabla_Reader t_tabla;
        
        public FormCantidadMedallas()
        {
            InitializeComponent();
        }

        private void FormCantidadMedallas_Load(object sender, EventArgs e)
        {
            
            RellenarComboPaises();
        }

        //Rellenar el combo de los paises, con todos los paises.
        private void RellenarComboPaises()
        {
            String lista = "select * from paises";
            Class_Tabla_Reader ctr = new Class_Tabla_Reader(lista);

            try
            {
                ctr.Open();

                combo_paises.DataSource = ctr.Dtt;
                combo_paises.DisplayMember = "nombrePais";
                combo_paises.ValueMember = "codPais";
                combo_paises.SelectedIndex = -1;
                //Dejar seleccionado uno para que se vean los valores en los label.
                combo_paises.SelectedIndex = 0;

                ctr.Close();
            }
            catch
            {
                MessageBox.Show("No se ha podido cargar la tabla.");
            }

        }

        //listener del ComboBox que ejecuta la función.
        private void combo_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
            RellenarTabla();
        }

        //Rellenar los label con los valores que se recogen del procedimiento.
        private void RellenarTabla()
        {
            //Parámetro de entrada, el país seleccionado del ComboBox.
            SqlParameter parPais = new SqlParameter("@Ppais", SqlDbType.VarChar);
            parPais.Value = combo_paises.Text;
            parPais.Direction = ParameterDirection.Input;

            //Parámetro de salida, con el número de medallas de oro.
            SqlParameter par1 = new SqlParameter("@cmedallaso", SqlDbType.Int);
            par1.Direction = ParameterDirection.Output;

            //Parámetro de salida, con el número de medallas de plata.
            SqlParameter par2 = new SqlParameter("@cmedallasp", SqlDbType.Int);
            par2.Direction = ParameterDirection.Output;

            //Parámetro de salida, con el número de medallas de bronce.
            SqlParameter par3 = new SqlParameter("@cmedallasb", SqlDbType.Int);
            par3.Direction = ParameterDirection.Output;

            //Añadir a la consulta, los parámetros.
            t_tabla = new Class_Tabla_Reader("pCantidadMedallas");
            t_tabla.Command.CommandType = CommandType.StoredProcedure;
            t_tabla.Command.Parameters.Add(parPais);
            t_tabla.Command.Parameters.Add(par1);
            t_tabla.Command.Parameters.Add(par2);
            t_tabla.Command.Parameters.Add(par3);
            
            //Ejecutar la consulta.
            t_tabla.Open();

            //Recoger de lo ejecutado, los valores.
            t_tabla.Command.ExecuteScalar();
            String oro = t_tabla.Command.Parameters["@cmedallaso"].Value.ToString();
            String plata = t_tabla.Command.Parameters["@cmedallasp"].Value.ToString();
            String bronce = t_tabla.Command.Parameters["@cmedallasb"].Value.ToString();
            
            t_tabla.Close();

            //Mostrar esos valores en los label.
            oroLabel.Text = oro;
            plataLabel.Text = plata;
            bronceLabel.Text = bronce;


        }


    }
}
