﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Carlos_OlimpiadasBD.Controller;

namespace Carlos_OlimpiadasBD.View_Procedimientos
{
    public partial class FormListarDeportistas : Form
    {
        DataSet ds;
        Class_Tabla_Adapter t_tabla;

        public FormListarDeportistas()
        {
            InitializeComponent();
        }

        private void FormListarDeportistas_Load(object sender, EventArgs e)
        {
            ds = new DataSet();

            RellenarComboPaises();
        }

        //Rellenar el ComboBox con los paises de la base de datos.
        private void RellenarComboPaises()
        {
            String lista = "select * from paises";
            Class_Tabla_Reader ctr = new Class_Tabla_Reader(lista);

            try
            {
                ctr.Open();

                combo_paises.DataSource = ctr.Dtt;
                combo_paises.DisplayMember = "nombrePais";
                combo_paises.ValueMember = "codPais";
                combo_paises.SelectedIndex = -1;
                combo_paises.SelectedIndex = 0;
                ctr.Close();
            }
            catch
            {
                MessageBox.Show("No se ha podido cargar la tabla.");
            }

        }

        //Listener del ComboBox, que ejecuta esa función.
        private void combo_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
            RellenarTabla();
        }

        //Ejecutar el procedimiento almacenado de la base de datos.
        private void RellenarTabla()
        {
            ds.Clear();

            String query = "pListaDeportistas";
            String tabla = "t_deportistas";
            String[] camposTabla = new String[] { "Nombre"};

            //Parámetro para el procedimiento, el país seleccionado del ComboBox.
            SqlParameter parameter = new SqlParameter("@Ppais", SqlDbType.VarChar);
            parameter.Direction = ParameterDirection.Input;
            parameter.Value = combo_paises.Text;

            t_tabla = new Class_Tabla_Adapter(query, tabla, camposTabla, ds, dgv_deportistas);
            t_tabla.Da.SelectCommand.CommandType = CommandType.StoredProcedure;
            t_tabla.Da.SelectCommand.Parameters.Add(parameter);
            t_tabla.Open();
            t_tabla.Da.SelectCommand.ExecuteScalar();

            try
            {
                t_tabla.CargarTabla();
            }
            catch
            {

            }


        }

    }
}
